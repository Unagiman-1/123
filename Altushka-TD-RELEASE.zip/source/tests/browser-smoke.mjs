import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { chromium } from "playwright";

const expected = ['altushka','girlfriend','granny','speaker','cat','kiosk','patrol','boss','skuf'];
const browser = await chromium.launch({ headless: true, args: ["--no-sandbox", "--enable-unsafe-swiftshader"] });
const errors = [], remote = [];
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
await page.addInitScript(() => {
  window.__smallTextureUploads = 0;
  window.__locationUploads = 0;
  for (const cls of [window.WebGLRenderingContext, window.WebGL2RenderingContext]) {
    if (!cls) continue;
    const original = cls.prototype.texImage2D;
    cls.prototype.texImage2D = function (...args) {
      const source = args[args.length - 1];
      if (source instanceof HTMLCanvasElement && source.width === 343 && source.height === 512) window.__smallTextureUploads++;
      if (source instanceof HTMLImageElement && source.naturalWidth === 1536 && source.naturalHeight === 1024) window.__locationUploads++;
      return original.apply(this, args);
    };
  }
});
page.on('pageerror', error => errors.push(error.message));
page.on('console', msg => { if (msg.type() === 'error') errors.push(msg.text()); });
page.on('request', req => { if (/^https?:/.test(req.url())) remote.push(req.url()); });
try {
  await page.goto(pathToFileURL(resolve('dist/index.html')).href);
  const background = await page.locator('.menu-screen').evaluate(el => getComputedStyle(el).getPropertyValue('--courtyard-image'));
  const match = background.match(/data:image\/jpeg;base64,([^"\)]+)/);
  assert.ok(match, 'original courtyard image is embedded in the menu');
  const digest = data => createHash('sha256').update(data).digest('hex');
  assert.equal(digest(Buffer.from(match[1], 'base64')), digest(await readFile('src/art/locations/courtyard.jpg')), 'menu embeds exact location original');
  assert.match(await page.locator('.map-thumb').first().evaluate(el => getComputedStyle(el).backgroundImage), /data:image\/jpeg;base64/);
  await page.getByRole('button', { name: 'Арты и анимация' }).click();
  await page.getByRole('dialog').waitFor();
  const rows = page.locator('.studio-roster button img');
  assert.equal(await rows.count(), 9, 'all original units appear in the art studio');
  for (let i = 0; i < expected.length; i++) {
    const item = rows.nth(i);
    await item.evaluate(img => img.decode());
    const data = await item.getAttribute('src');
    assert.match(data, /^data:image\/webp;base64,/);
    const hash = bytes => createHash('sha256').update(bytes).digest('hex');
    const actual = hash(Buffer.from(data.split(',')[1], 'base64'));
    const original = hash(await readFile(`src/art/units/source-${expected[i]}.webp`));
    assert.equal(actual, original, `exact bytes of ${expected[i]}`);
  }
  await page.locator('.studio-roster button').nth(4).click();
  assert.equal(await page.getByRole('button', {name:'Шаг', exact:true}).isDisabled(), true, 'seated cat cannot walk');
  await page.locator('.studio-roster button').nth(1).click();
  assert.equal(await page.getByRole('button', {name:'Шаг', exact:true}).isEnabled(), true, 'standing full-body character can walk');
  await page.locator('.studio-roster button').first().click();
  await page.getByRole('button', { name: 'Сравнить с исходником' }).click();
  await page.getByRole('button', { name: 'Исходник', exact: true }).click();
  assert.equal(await page.locator('.studio-reference img').count(), 1);
  const png = await page.evaluate(() => {const c=document.createElement('canvas');c.width=64;c.height=96;const x=c.getContext('2d');x.fillStyle='white';x.fillRect(0,0,64,96);x.fillStyle='#25334f';x.fillRect(12,12,40,72);return c.toDataURL('image/png').split(',')[1]});
  await page.getByLabel('Загрузить оригинал персонажа').setInputFiles({ name:'fixture.png', mimeType:'image/png', buffer:Buffer.from(png,'base64') });
  await page.getByText('Исходник применён и сохранён на этом устройстве.', {exact:true}).waitFor({timeout:15000});
  assert.equal(await page.locator('.studio-animated canvas').getAttribute('data-art-source'), 'uploaded');
  await page.getByRole('button', { name: 'Закрыть арт-студию' }).click();
  assert.equal(await page.locator('.menu-altushka img').getAttribute('data-art-source'), 'uploaded');
  await page.getByRole('button', { name: 'ВОЙТИ ВО ДВОР' }).click();
  await page.locator('canvas').waitFor();
  await page.waitForFunction(() => document.querySelector('.rail-portrait img')?.getAttribute('data-art-source') === 'uploaded');
  await page.waitForTimeout(2500);
  await page.getByRole('button', {name:'Подруга, 70 монет'}).click();
  await page.waitForFunction(() => document.querySelector('.resource.coins b')?.textContent === '200');
  await page.getByRole('button', {name:/НАЧАТЬ ПЕРВУЮ ВОЛНУ/}).click();
  await page.waitForFunction(() => document.querySelector('.wave-heading b')?.textContent === 'Волна 1');
  await page.getByRole('button', {name:/Улучшить до уровня 2/}).click();
  await page.getByText('ВЫБЕРИ ВЕТКУ УЛУЧШЕНИЯ').waitFor();
  const ability = page.locator('.ability-button').first();
  await ability.click();
  await page.locator('.game-canvas canvas').click({position:{x:500,y:250}});
  await page.waitForFunction(() => document.querySelector('.ability-button')?.disabled);
  await page.waitForTimeout(1000);
  await page.keyboard.press('Space');
  await page.getByText('Пауза', {exact:true}).waitFor();
  await page.getByRole('button', {name:'Продолжить'}).click();
  await page.reload();
  await page.getByRole('button', { name: 'Арты и анимация' }).click();
  await page.waitForFunction(() => document.querySelector('.studio-animated canvas')?.getAttribute('data-art-source') === 'uploaded');
  await page.getByRole('button', {name:'Вернуть арт проекта'}).click();
  await page.getByText('Восстановлен арт из проекта.', {exact:true}).waitFor();
  await page.reload();
  await page.getByRole('button', { name: 'Арты и анимация' }).click();
  assert.equal(await page.locator('.studio-animated canvas').getAttribute('data-art-source'), 'builtin');
  await page.getByRole('button', { name: 'Закрыть арт-студию' }).click();
  await page.getByRole('button', { name: 'ВОЙТИ ВО ДВОР' }).click();
  await page.locator('canvas').waitFor();
  await page.waitForTimeout(3000);
  assert.ok(await page.evaluate(() => window.__smallTextureUploads > 0), 'battle uses reduced-size GPU textures');
  assert.ok(await page.evaluate(() => window.__locationUploads > 0), 'original courtyard is loaded into the battle renderer');
  if (process.env.SCREENSHOT) await page.screenshot({path:process.env.SCREENSHOT});
  for (const [index, name] of [[0, 'Двор на Осыпной'], [1, 'Арка на Ломаной'], [2, 'Котельная «Рассвет»']]) {
    await page.goto(pathToFileURL(resolve('dist/index.html')).href);
    await page.evaluate(() => localStorage.setItem('altushka-td-meta-v2', JSON.stringify({records:{},totalStars:6,runs:0,totalKillsScore:0})));
    await page.reload();
    await page.locator('.map-card').nth(index).click();
    await page.getByRole('button', {name:'ВОЙТИ ВО ДВОР'}).click();
    await page.locator('.game-canvas canvas').waitFor();
    await page.waitForFunction(() => window.__locationUploads > 0, {timeout:15000});
    assert.equal(await page.locator('.canvas-location small').textContent(), name, `correct map ${name}`);
    await page.getByRole('button', {name:/НАЧАТЬ ПЕРВУЮ ВОЛНУ/}).click();
    await page.waitForFunction(() => document.querySelector('.wave-heading b')?.textContent === 'Волна 1');
  }
  assert.deepEqual(remote, [], `standalone should make no external requests: ${remote}`);
  assert.deepEqual(errors, [], `runtime errors: ${errors}`);
  console.log('PASS: offline file launch; original location and characters, all three maps, smaller GPU textures; studio compare/upload/save/reload/reset; uploaded art in game; purchase; first wave; upgrade and ability; pause/resume; clean browser console.');
} finally { await browser.close(); }
