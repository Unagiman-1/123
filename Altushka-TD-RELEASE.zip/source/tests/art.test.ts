import assert from "node:assert/strict";
import { test } from "node:test";
import { removeEdgeBackground } from "../src/game/alpha-mask";
import { ART_UNITS } from "../src/game/art-types";
import { sourcePoint } from "../src/game/source-motion";

function fixture() {
  const pixels = new Uint8ClampedArray(9 * 9 * 4).fill(255);
  for (let y = 2; y < 7; y++) for (let x = 2; x < 7; x++) {
    const p = (y * 9 + x) * 4;
    pixels[p] = 37; pixels[p + 1] = 51; pixels[p + 2] = 79;
  }
  // A white interior patch represents white clothing, not the external backdrop.
  const center = (4 * 9 + 4) * 4;
  pixels[center] = pixels[center + 1] = pixels[center + 2] = 255;
  return pixels;
}

test("white-key removes only border-connected background and preserves RGB", () => {
  const pixels = fixture(), before = pixels.slice();
  const report = removeEdgeBackground(pixels, 9, 9, "white");
  assert.equal(report.removed, 56);
  assert.equal(pixels[(4 * 9 + 4) * 4 + 3], 255);
  for (let p = 0; p < pixels.length; p += 4) assert.deepEqual([...pixels.slice(p, p + 3)], [...before.slice(p, p + 3)]);
});

test("transparent PNGs pass auto-key without changing any pixel", () => {
  const pixels = fixture(); pixels[3] = 0;
  const before = pixels.slice();
  assert.equal(removeEdgeBackground(pixels, 9, 9, "auto").applied, "none");
  assert.deepEqual(pixels, before);
});

test("no-key mode is exactly identical to the input", () => {
  const pixels = fixture(), before = pixels.slice();
  removeEdgeBackground(pixels, 9, 9, "none");
  assert.deepEqual(pixels, before);
});

test("black-key never invents white fill or recolours pixels", () => {
  const pixels = fixture();
  for (let i = 0; i < pixels.length; i += 4) if (pixels[i] === 255 && pixels[i + 1] === 255 && pixels[i + 2] === 255) pixels[i] = pixels[i + 1] = pixels[i + 2] = 0;
  assert.equal(removeEdgeBackground(pixels, 9, 9, "black").removed, 56);
  assert.equal(pixels[(4 * 9 + 4) * 4 + 3], 255);
});

test("neutral reference mode never changes source geometry", () => {
  for (const unit of ART_UNITS) for (const x of [0, 0.25, 0.5, 0.75, 1]) for (const y of [0, 0.25, 0.5, 0.75, 1]) {
    assert.deepEqual(sourcePoint(x, y, unit, { time: 5, phase: 1.5, walking: true, attack: 1, neutral: true }, true), [x, y]);
  }
});

test("source mesh remains continuous and never folds during motion", () => {
  for (const unit of ART_UNITS) for (const time of [0, Math.PI / 16, 0.6, 1.2, 2.1, 3.6]) for (const attack of [0, 0.5, 1]) {
    const pose = { time, phase: time * 8, walking: true, attack };
    for (let y = 0; y < 26; y++) for (let x = 0; x < 16; x++) {
      const a = sourcePoint(x / 16, y / 26, unit, pose, true);
      const b = sourcePoint((x + 1) / 16, y / 26, unit, pose, true);
      const c = sourcePoint(x / 16, (y + 1) / 26, unit, pose, true);
      const d = sourcePoint((x + 1) / 16, (y + 1) / 26, unit, pose, true);
      assert.ok((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]) > 0, `Folded triangle in ${unit}`);
      assert.ok((d[0] - b[0]) * (c[1] - b[1]) - (d[1] - b[1]) * (c[0] - b[0]) > 0, `Folded second triangle in ${unit}`);
    }
  }
});

test("portrait-only artwork does not receive synthesized leg motion", () => {
  const p = { time: 1, phase: Math.PI / 2, walking: true };
  assert.deepEqual(sourcePoint(0.2, 1, "girlfriend", p, false), [0.2, 1]);
  assert.notDeepEqual(sourcePoint(0.2, 1, "altushka", p, true), [0.2, 1]);
});