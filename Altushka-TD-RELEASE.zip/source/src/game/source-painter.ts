import { getArtwork } from "./art-library";
import type { Artwork, ArtPose, ArtUnit } from "./art-types";
import { sourcePoint } from "./source-motion";

const COLS = 16, ROWS = 26, BORDER = 0.065;
const MAX_FRAME_BYTES = 18 * 1024 * 1024;

function shader(gl: WebGLRenderingContext, type: number, code: string) {
  const compiled = gl.createShader(type);
  if (!compiled) throw new Error("No shader memory");
  gl.shaderSource(compiled, code); gl.compileShader(compiled);
  if (!gl.getShaderParameter(compiled, gl.COMPILE_STATUS)) { gl.deleteShader(compiled); throw new Error("Source art shader unavailable"); }
  return compiled;
}

class SourceMesh {
  canvas = document.createElement("canvas");
  private gl: WebGLRenderingContext | null;
  private program: WebGLProgram | null = null;
  private vertex: WebGLBuffer | null = null;
  private index: WebGLBuffer | null = null;
  private vertices = new Float32Array((COLS + 1) * (ROWS + 1) * 4);
  private textures = new Map<ArtUnit, { revision: number; texture: WebGLTexture }>();
  private position = 0;
  private uv = 0;
  private count = COLS * ROWS * 6;
  private maxTexture = 2048;
  private sampler: WebGLUniformLocation | null = null;

  constructor() {
    this.gl = this.canvas.getContext("webgl", { alpha: true, premultipliedAlpha: true, antialias: false, depth: false, stencil: false, preserveDrawingBuffer: false });
    this.canvas.addEventListener("webglcontextlost", (event) => { event.preventDefault(); this.gl = null; });
    const gl = this.gl;
    if (!gl) return;
    try {
      const vertex = shader(gl, gl.VERTEX_SHADER, "attribute vec2 a_position; attribute vec2 a_uv; varying vec2 v_uv; void main(){gl_Position=vec4(a_position.x*2.0-1.0,1.0-a_position.y*2.0,0.0,1.0);v_uv=a_uv;}");
      const fragment = shader(gl, gl.FRAGMENT_SHADER, "precision mediump float; varying vec2 v_uv; uniform sampler2D u_image; void main(){gl_FragColor=texture2D(u_image,v_uv);}");
      const program = gl.createProgram();
      if (!program) return;
      gl.attachShader(program, vertex); gl.attachShader(program, fragment); gl.linkProgram(program);
      gl.deleteShader(vertex); gl.deleteShader(fragment);
      if (!gl.getProgramParameter(program, gl.LINK_STATUS)) { this.gl = null; return; }
      this.program = program; this.position = gl.getAttribLocation(program, "a_position"); this.uv = gl.getAttribLocation(program, "a_uv");
      this.maxTexture = gl.getParameter(gl.MAX_TEXTURE_SIZE) as number;
      this.sampler = gl.getUniformLocation(program, "u_image");
      this.vertex = gl.createBuffer(); this.index = gl.createBuffer();
      const indices = new Uint16Array(this.count);
      let p = 0;
      for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS; x++) {
        const a = y * (COLS + 1) + x, b = a + 1, c = a + COLS + 1, d = c + 1;
        indices[p++] = a; indices[p++] = b; indices[p++] = c; indices[p++] = b; indices[p++] = d; indices[p++] = c;
      }
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.index); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indices, gl.STATIC_DRAW);
      gl.disable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE); gl.disable(gl.BLEND);
    } catch { this.gl = null; }
  }

  render(art: Artwork, pose: ArtPose, width: number, height: number): HTMLCanvasElement | null {
    const gl = this.gl;
    if (!gl || !this.program || gl.isContextLost()) return null;
    if (art.width > this.maxTexture || art.height > this.maxTexture) return null;
    if (this.canvas.width !== width || this.canvas.height !== height) { this.canvas.width = width; this.canvas.height = height; }
    gl.viewport(0, 0, width, height); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
    let texture = this.textures.get(art.unit);
    if (!texture || texture.revision !== art.revision) {
      if (texture) gl.deleteTexture(texture.texture);
      const created = gl.createTexture(); if (!created) return null;
      gl.bindTexture(gl.TEXTURE_2D, created); gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, art.image);
      texture = { revision: art.revision, texture: created }; this.textures.set(art.unit, texture);
    }
    let p = 0;
    for (let y = 0; y <= ROWS; y++) for (let x = 0; x <= COLS; x++) {
      const u = x / COLS, v = y / ROWS;
      const [px, py] = sourcePoint(u, v, art.unit, pose, art.fullBody);
      this.vertices[p++] = (px + BORDER) / (1 + BORDER * 2); this.vertices[p++] = (py + BORDER) / (1 + BORDER * 2);
      this.vertices[p++] = u; this.vertices[p++] = v;
    }
    gl.useProgram(this.program); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, texture.texture);
    gl.uniform1i(this.sampler, 0);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.vertex); gl.bufferData(gl.ARRAY_BUFFER, this.vertices, gl.DYNAMIC_DRAW);
    gl.enableVertexAttribArray(this.position); gl.vertexAttribPointer(this.position, 2, gl.FLOAT, false, 16, 0);
    gl.enableVertexAttribArray(this.uv); gl.vertexAttribPointer(this.uv, 2, gl.FLOAT, false, 16, 8);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.index); gl.drawElements(gl.TRIANGLES, this.count, gl.UNSIGNED_SHORT, 0);
    return this.canvas;
  }
}

interface CachedFrame { canvas: HTMLCanvasElement; bytes: number }
let mesh: SourceMesh | null = null;
const cache = new Map<string, CachedFrame>();
let cacheBytes = 0;
export function sourceCacheStats() { return { frames: cache.size, bytes: cacheBytes, limit: MAX_FRAME_BYTES }; }

export class PuppetPainter {
  draw(ctx: CanvasRenderingContext2D, unit: ArtUnit, pose: ArtPose, height = 100) {
    const art = getArtwork(unit);
    if (!art.ready) return;
    const width = height * art.width / art.height;
    if (pose.neutral) { ctx.drawImage(art.image, -width / 2, -height, width, height); return; }
    // Large inspection portraits are rendered continuously instead of evicting
    // the whole small-sprite cache or quantizing a slow head turn into steps.
    if (height > 230) {
      mesh ??= new SourceMesh();
      const h = Math.round(Math.min(800, height * (1 + BORDER * 2)));
      const w = Math.max(1, Math.round(Math.min(2048, h * art.width / art.height)));
      const continuous = mesh.render(art, pose, w, h);
      if (continuous) {
        ctx.drawImage(continuous, -width * (0.5 + BORDER), -height * (1 + BORDER), width * (1 + BORDER * 2), height * (1 + BORDER * 2));
        return;
      }
    }
    const walking = !!pose.walking;
    const attackFrame = Math.round(Math.max(0, Math.min(1, pose.attack ?? 0)) * 9);
    const phaseFrame = Math.floor((((pose.phase ?? 0) % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2) / (Math.PI * 2) * 16);
    const idleFrame = Math.floor((((pose.time / 4.8) % 1) + 1) % 1 * 24);
    const size = height > 125 ? 256 : 160;
    const key = `${unit}:${art.revision}:${size}:${walking ? "w" + phaseFrame : "i" + idleFrame}:a${attackFrame}`;
    let frame = cache.get(key);
    if (!frame) {
      const ratio = art.width / art.height;
      const h = Math.max(1, Math.round(Math.min(size * (1 + BORDER * 2), 2048 / Math.max(1, ratio))));
      const w = Math.max(1, Math.round(h * ratio));
      mesh ??= new SourceMesh();
      const sampledPose: ArtPose = { time: walking ? 0 : idleFrame / 24 * 4.8, phase: walking ? phaseFrame / 16 * Math.PI * 2 : 0, walking, attack: attackFrame / 9 };
      const result = mesh.render(art, sampledPose, w, h);
      if (result) {
        const canvas = document.createElement("canvas"); canvas.width = w; canvas.height = h; canvas.getContext("2d")?.drawImage(result, 0, 0);
        frame = { canvas, bytes: w * h * 4 };
        while (cacheBytes + frame.bytes > MAX_FRAME_BYTES && cache.size) { const oldest = cache.keys().next().value!; cacheBytes -= cache.get(oldest)!.bytes; cache.delete(oldest); }
        cache.set(key, frame); cacheBytes += frame.bytes;
      }
    } else { cache.delete(key); cache.set(key, frame); }
    if (frame) ctx.drawImage(frame.canvas, -width * (0.5 + BORDER), -height * (1 + BORDER), width * (1 + BORDER * 2), height * (1 + BORDER * 2));
    else {
      // Hardware fallback retains the source instead of inventing a replacement.
      ctx.save(); ctx.rotate(Math.sin(pose.time * 1.3) * 0.008); ctx.drawImage(art.image, -width / 2, -height, width, height); ctx.restore();
    }
  }
}