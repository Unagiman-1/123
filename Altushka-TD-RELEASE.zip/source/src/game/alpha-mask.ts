import type { BackgroundKey } from "./art-types";

/** Only remove matching background connected to an image edge. RGB is untouched. */
export function removeEdgeBackground(rgba: Uint8ClampedArray, width: number, height: number, mode: BackgroundKey): { removed: number; applied: BackgroundKey } {
  if (mode === "none") return { removed: 0, applied: "none" };
  if (mode === "auto") {
    let transparent = false;
    for (let i = 3; i < rgba.length; i += 4) if (rgba[i] < 250) { transparent = true; break; }
    if (transparent) return { removed: 0, applied: "none" };
    const corners = [0, width - 1, (height - 1) * width, width * height - 1];
    mode = corners.every((index) => Math.min(rgba[index * 4], rgba[index * 4 + 1], rgba[index * 4 + 2]) > 230) ? "white" : "none";
    if (mode === "none") return { removed: 0, applied: "none" };
  }
  const target = mode === "black" ? 0 : 255;
  const count = width * height;
  const queue = new Uint32Array(count);
  const seen = new Uint8Array(count);
  let head = 0, tail = 0, removed = 0;
  const enqueue = (index: number) => {
    if (seen[index]) return;
    seen[index] = 1;
    const p = index * 4;
    if (rgba[p + 3] < 8 || Math.max(Math.abs(rgba[p] - target), Math.abs(rgba[p + 1] - target), Math.abs(rgba[p + 2] - target)) <= 24) queue[tail++] = index;
  };
  for (let x = 0; x < width; x++) { enqueue(x); enqueue((height - 1) * width + x); }
  for (let y = 1; y < height - 1; y++) { enqueue(y * width); enqueue(y * width + width - 1); }
  while (head < tail) {
    const index = queue[head++];
    if (rgba[index * 4 + 3] > 0) removed++;
    rgba[index * 4 + 3] = 0;
    const x = index % width;
    if (x > 0) enqueue(index - 1);
    if (x < width - 1) enqueue(index + 1);
    if (index >= width) enqueue(index - width);
    if (index < count - width) enqueue(index + width);
  }
  return { removed, applied: mode };
}