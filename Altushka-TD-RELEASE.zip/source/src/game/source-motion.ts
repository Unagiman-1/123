import type { ArtPose, ArtUnit } from "./art-types";

const clamp = (n: number) => Math.max(0, Math.min(1, n));
const smooth = (a: number, b: number, value: number) => { const t = clamp((value - a) / (b - a)); return t * t * (3 - 2 * t); };
const HEAD: Record<ArtUnit, [number, number]> = {
  altushka: [0.39, 0.15], girlfriend: [0.5, 0.32], granny: [0.38, 0.31],
  speaker: [0.52, 0.29], cat: [0.3, 0.29], kiosk: [0.5, 0.42],
  patrol: [0.5, 0.27], boss: [0.5, 0.28], skuf: [0.6, 0.28],
};

/** Shared mesh vertices prevent the holes and duplicated limbs of sliced puppets. */
export function sourcePoint(x: number, y: number, unit: ArtUnit, pose: ArtPose, fullBody: boolean): [number, number] {
  if (pose.neutral) return [x, y];
  const phase = pose.phase ?? 0;
  const breathe = Math.sin(pose.time * Math.PI * 2 / 4.8 + phase * 0.1);
  const attack = clamp(pose.attack ?? 0);
  const step = pose.walking ? Math.sin(phase) : 0;
  const [neckX, neckY] = HEAD[unit];
  const headWeight = 1 - smooth(neckY - 0.025, neckY + 0.1, y);
  const headAngle = breathe * 0.012 + attack * 0.018;
  const dx = x - neckX, dy = y - neckY;
  let px = x + (neckX + dx * Math.cos(headAngle) - dy * Math.sin(headAngle) - x) * headWeight;
  let py = y + (neckY + dx * Math.sin(headAngle) + dy * Math.cos(headAngle) - y) * headWeight;
  const chest = smooth(neckY, neckY + 0.16, y) * (1 - smooth(0.58, 0.82, y));
  px += breathe * 0.0028 * chest * (x - 0.5); py -= breathe * 0.003 * chest;
  const arm = smooth(0.48, 0.85, x) * smooth(neckY + 0.02, neckY + 0.2, y) * (1 - smooth(0.72, 0.92, y));
  px += attack * 0.035 * arm; py -= attack * 0.025 * arm;
  if (fullBody && pose.walking) {
    const leg = smooth(0.64, 0.95, y), side = Math.cos(x * Math.PI);
    px += step * leg * side * 0.035; py -= Math.max(0, step * side) * leg * 0.014;
  }
  const upperWeight = 1 - smooth(0.75, 1, y);
  px += (breathe * 0.003 + step * 0.012 + attack * 0.015) * upperWeight;
  py -= (pose.walking ? Math.abs(step) * 0.007 : 0) * upperWeight;
  return [px, py];
}