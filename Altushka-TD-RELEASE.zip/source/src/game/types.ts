export type DamageType = "soft" | "heavy" | "pierce" | "control";
export type EnemyTag = "flesh" | "helmet" | "armor" | "shield" | "swarm" | "flying" | "boss";
export type TargetMode = "first" | "last" | "strong" | "weak" | "close";
export type TowerId = "girlfriend" | "granny" | "cat" | "speaker" | "kiosk" | "patrol";
export type EnemyId =
  | "skuf" | "scooter" | "helmet" | "pigeons" | "armored" | "regen"
  | "courier" | "loudmouth" | "cop" | "drunk" | "crowd" | "boss";
export type PropId = "sofa" | "clothesline" | "dumpster" | "car";
export type GameStatus = "prep" | "wave" | "won" | "lost";
export type GameMode = "campaign" | "endless";

export interface Vec { x: number; y: number }

export interface BranchDef {
  id: string;
  name: string;
  description: string;
  capstone: string;
}

export interface TowerDef {
  id: TowerId;
  name: string;
  role: string;
  cost: number;
  damage: number;
  rate: number;
  range: number;
  damageType: DamageType;
  canAir: boolean;
  color: string;
  description: string;
  branches: [BranchDef, BranchDef];
}

export interface EnemyDef {
  id: EnemyId;
  name: string;
  short: string;
  hp: number;
  speed: number;
  reward: number;
  damage: number;
  tags: EnemyTag[];
  armor: number;
  resists: Partial<Record<DamageType, number>>;
  color: string;
  scale: number;
  behavior: string;
}

export interface WaveGroup {
  enemy: EnemyId;
  count: number;
  gap: number;
  delay?: number;
  lane?: number;
}

export interface WaveDef {
  name: string;
  tip: string;
  groups: WaveGroup[];
  bonus: number;
}

export interface PadDef extends Vec {
  id: number;
  unlockWave: number;
  unlockCost: number;
}

export interface MapDef {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  requiredStars: number;
  tint: string;
  paths: Vec[][];
  pads: PadDef[];
  props: (Vec & { id: number; allowed: PropId[] })[];
  hero: Vec;
}

export interface Tower {
  uid: number;
  type: TowerId;
  pad: number;
  level: number;
  branch: 0 | 1 | null;
  cooldown: number;
  targetMode: TargetMode;
  kills: number;
  damageDone: number;
  invested: number;
  buffUntil: number;
  disabledUntil: number;
  recoil: number;
  shots: number;
  facing: 1 | -1;
}

export interface Enemy {
  uid: number;
  type: EnemyId;
  lane: number;
  progress: number;
  hp: number;
  maxHp: number;
  shield: number;
  maxShield: number;
  speed: number;
  slowUntil: number;
  slowFactor: number;
  stunUntil: number;
  heldUntil: number;
  flash: number;
  dead: boolean;
  leaked: boolean;
  wobble: number;
  phase: number;
  abilityTimer: number;
  telegraph: number;
  telegraphKind: "slam" | "summon" | "rage" | null;
  spawnScale: number;
  stolen: number;
  hitAgo: number;
  vulnerableUntil: number;
  walking: boolean;
}

export interface Projectile {
  uid: number;
  from: Vec;
  to: Vec;
  targetUid: number;
  towerUid: number;
  damage: number;
  type: DamageType;
  speed: number;
  life: number;
  color: string;
  aoe: number;
  crit: boolean;
}

export interface Particle {
  x: number; y: number; vx: number; vy: number;
  life: number; maxLife: number; size: number; color: string;
  kind: "spark" | "leaf" | "text" | "coin" | "ring";
  text?: string;
}

export interface Prop {
  uid: number;
  type: PropId;
  spot: number;
  hp: number;
  maxHp: number;
  cooldown: number;
  triggered: boolean;
}

export interface ActiveEffect {
  kind: "bucket" | "chord" | "cat";
  x: number; y: number; radius: number;
  life: number; tick: number;
}

export interface Snapshot {
  coins: number;
  lives: number;
  maxLives: number;
  wave: number;
  status: GameStatus;
  speed: number;
  paused: boolean;
  enemies: number;
  selectedPad: number | null;
  selectedTowerUid: number | null;
  selectedTower: Tower | null;
  selectedProp: Prop | null;
  selectedSpot: number | null;
  pendingTower: TowerId | null;
  unlockedPads: number[];
  towers: Tower[];
  props: Prop[];
  cooldowns: Record<string, number>;
  targeting: "bucket" | "chord" | "cat" | null;
  nextWave: WaveDef;
  currentWave: WaveDef;
  intermission: number;
  waveActive: boolean;
  totalWaveHp: number;
  killedWaveHp: number;
  earlyBonus: number;
  starsEarned: number;
  score: number;
  links: { a: number; b: number; name: string; color: string }[];
  notice: { text: string; sub: string; time: number } | null;
  boss: { name: string; hp: number; maxHp: number; phase: number; telegraph: string | null } | null;
  waveProgress: number;
  totalSpawned: number;
  totalInWave: number;
  endless: boolean;
  perks: string[];
  draft: string[] | null;
  fps: number;
}
