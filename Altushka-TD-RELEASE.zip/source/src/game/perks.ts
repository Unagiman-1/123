export const PERKS = [
  { id: "tempo", name: "Общий ритм", art: "speaker", description: "Все боевые жители атакуют на 8% быстрее." },
  { id: "glass", name: "Острая слёзка", art: "girlfriend", description: "Подруга наносит на 20% больше урона." },
  { id: "iron", name: "Чугунная нота", art: "granny", description: "Баба Валя наносит на 18% больше урона." },
  { id: "catEyes", name: "Кошачий глаз", art: "cat", description: "Радиус кота увеличен на 30." },
  { id: "bass", name: "Низкий фон", art: "speaker", description: "Динамик наносит на 35% больше урона." },
  { id: "kiosk", name: "Общая касса", art: "kiosk", description: "Каждая выплата киоска приносит ещё 3 монеты." },
  { id: "props", name: "Крепкий хлам", art: "patrol", description: "Новые объекты двора имеют на 60% больше прочности." },
  { id: "cold", name: "Холодный рассудок", art: "altushka", description: "Перезарядка способностей Алтушки на 20% короче." },
  { id: "watch", name: "Ночной дозор", art: "patrol", description: "Удержание Дозорного длится на 0,25 с дольше." },
  { id: "bell", name: "Первый звонок", art: "kiosk", description: "Досрочный вызов волны даёт на 50% больше монет." },
  { id: "threshold", name: "Последний порог", art: "altushka", description: "Подъезд сразу получает +4 HP и +4 к максимуму." },
  { id: "bossBane", name: "Сбор подписей", art: "boss", description: "Управдом получает на 20% больше урона от всех источников." },
  { id: "neighbors", name: "Дружный подъезд", art: "granny", description: "Синкопа даёт +65%, а крит связки кота — ×2,25." },
  { id: "lines", name: "Длинные верёвки", art: "girlfriend", description: "Радиус бельевых верёвок увеличен с 90 до 130." },
] as const;

export type PerkId = (typeof PERKS)[number]["id"];
export const perkById = (id: string) => PERKS.find((perk) => perk.id === id);
