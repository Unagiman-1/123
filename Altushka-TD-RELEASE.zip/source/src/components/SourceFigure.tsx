import { useEffect, useRef, useSyncExternalStore } from "react";
import { getArtwork, getArtVersion, subscribeArt } from "../game/art-library";
import { PuppetPainter } from "../game/source-painter";
import { ART_NAMES, type ArtUnit, type MotionKind } from "../game/art-types";

export function SourceFigure({ unit, motion = "idle", playing = true, progress = 0, className = "" }: { unit: ArtUnit; motion?: MotionKind; playing?: boolean; progress?: number; className?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const controls = useRef({ motion, playing, progress });
  controls.current = { motion, playing, progress };
  const version = useSyncExternalStore(subscribeArt, getArtVersion);
  const art = getArtwork(unit);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const painter = new PuppetPainter();
    let raf = 0, clock = 0, previous = 0, lastDraw = -1;
    let width = 0, height = 0;
    const resize = new ResizeObserver(([entry]) => { width = entry.contentRect.width; height = entry.contentRect.height; });
    resize.observe(canvas);
    const reduce = matchMedia("(prefers-reduced-motion: reduce)");
    const render = (now: number) => {
      if (!previous) previous = now;
      const { playing, motion, progress } = controls.current;
      if (playing && !reduce.matches && !document.hidden) clock += Math.min(0.08, (now - previous) / 1000);
      previous = now;
      if (now - lastDraw > 32 && width && height && !document.hidden) {
        const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
        const w = Math.round(width * dpr), h = Math.round(height * dpr);
        if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
        const context = canvas.getContext("2d");
        if (context) {
          context.clearRect(0, 0, w, h);
          const source = getArtwork(unit);
          const figureHeight = Math.min(h * 0.94, w * 0.9 * source.height / source.width);
          context.save(); context.translate(w / 2, h * 0.97);
          const time = playing ? clock : progress * 4.8;
          painter.draw(context, unit, { time, phase: time * 9, walking: motion === "walk", attack: motion === "attack" ? Math.max(0, Math.sin(time * 3)) : 0, neutral: motion === "neutral" || reduce.matches }, figureHeight);
          context.restore();
        }
        lastDraw = now;
      }
      raf = requestAnimationFrame(render);
    };
    raf = requestAnimationFrame(render);
    return () => { cancelAnimationFrame(raf); resize.disconnect(); };
  }, [unit, version]);

  return <canvas ref={ref} className={`source-figure ${className}`} role="img" aria-label={`Исходный арт: ${ART_NAMES[unit]}`} data-art-source={art.source} />;
}

export { ArtPortrait } from "./ArtPortrait";
