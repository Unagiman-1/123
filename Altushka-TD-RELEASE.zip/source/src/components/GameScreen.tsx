import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft, AudioLines, Car, Cat, Check, ChevronUp, CloudRain, Coins,
  Crosshair, FastForward, Gauge, Heart, HelpCircle, Home, Link2, LockKeyhole,
  MousePointer2, Pause, Play, RotateCcw, Shield, Shirt, Sofa, Star, Swords,
  Timer, Trash2, TrendingUp, Users, Volume2, VolumeX, X, Zap,
} from "lucide-react";
import { Game } from "../game/engine";
import { ABILITIES, ENEMIES, MAX_WAVE, PROP_DATA, TOWERS } from "../game/data";
import { audio } from "../game/audio";
import { perkById, type PerkId } from "../game/perks";
import type { GameMode, PropId, Snapshot, TargetMode, TowerId } from "../game/types";
import { GameCanvas } from "./GameCanvas";
import { ArtPortrait } from "./ArtPortrait";

const towerIds = Object.keys(TOWERS) as TowerId[];
const targetModes: { id: TargetMode; short: string; name: string }[] = [
  { id: "first", short: "ПЕРВ", name: "Первый к выходу" },
  { id: "last", short: "ПОСЛ", name: "Последний в колонне" },
  { id: "strong", short: "СИЛЬ", name: "Максимум HP и щита" },
  { id: "weak", short: "СЛАБ", name: "Минимум HP и щита" },
  { id: "close", short: "БЛИЖ", name: "Ближайший к башне" },
];
const damageNames = { soft: "Мягкий", heavy: "Тяжёлый", pierce: "Пробитие", control: "Контроль" };
const propIcons: Record<PropId, React.ReactNode> = {
  sofa: <Sofa size={19} />, clothesline: <Shirt size={19} />, dumpster: <Trash2 size={19} />, car: <Car size={19} />,
};

interface Props {
  mapId: string;
  mode: GameMode;
  seed: number;
  onExit: () => void;
  onRestart: () => void;
  onComplete: (result: { wave: number; score: number; stars: number }) => void;
}

export function GameScreen({ mapId, mode, seed, onExit, onRestart, onComplete }: Props) {
  const game = useMemo(() => new Game(mapId, mode, seed), [mapId, mode, seed]);
  const [snap, setSnap] = useState<Snapshot>(() => game.snapshot());
  const [tab, setTab] = useState<"people" | "props">("people");
  const [sound, setSound] = useState(audio.isEnabled);
  const [help, setHelp] = useState(false);
  const completed = useRef(false);

  const refresh = useCallback(() => setSnap(game.snapshot()), [game]);
  const build = useCallback((type: TowerId) => {
    game.prepareTower(type);
    refresh();
  }, [game, refresh]);

  const togglePause = useCallback(() => {
    if (game.status === "won" || game.status === "lost") return;
    game.paused = !game.paused;
    game.targeting = null;
    refresh();
  }, [game, refresh]);

  useEffect(() => {
    const keydown = (event: KeyboardEvent) => {
      if (event.repeat) return;
      if (event.code === "Space") { event.preventDefault(); togglePause(); return; }
      if (event.code === "Escape") {
        if (help) setHelp(false);
        else if (game.targeting) { game.targeting = null; refresh(); }
        else if (game.pendingTower) { game.pendingTower = null; refresh(); }
        else togglePause();
        return;
      }
      if (event.code === "KeyQ") game.armAbility("bucket");
      if (event.code === "KeyW") game.armAbility("chord");
      if (event.code === "KeyE") game.armAbility("cat");
      if (event.code === "KeyF" && !game.waveActive) game.startWave();
      if (/^Digit[1-6]$/.test(event.code)) {
        const index = Number(event.code.slice(-1)) - 1;
        game.prepareTower(towerIds[index]);
      }
      if (event.code === "Digit0") game.speed = game.speed === 1 ? 2 : 1;
      refresh();
    };
    window.addEventListener("keydown", keydown);
    return () => window.removeEventListener("keydown", keydown);
  }, [game, help, refresh, togglePause]);

  useEffect(() => {
    if ((snap.status === "won" || snap.status === "lost") && !completed.current) {
      completed.current = true;
      onComplete({ wave: snap.wave, score: snap.score, stars: snap.starsEarned });
    }
  }, [snap.status, snap.wave, snap.score, snap.starsEarned, onComplete]);

  const selectedTower = snap.selectedTower;
  const selectedPad = game.map.pads.find((p) => p.id === snap.selectedPad) ?? null;
  const selectedSpot = game.map.props.find((p) => p.id === snap.selectedSpot) ?? null;
  const previewWave = snap.waveActive ? snap.currentWave : snap.nextWave;
  const selectedStats = selectedTower ? game.towerStats(selectedTower) : null;
  const activeLinks = selectedTower ? snap.links.filter((l) => l.a === selectedTower.pad || l.b === selectedTower.pad) : [];

  const arm = (kind: "bucket" | "chord" | "cat") => { game.armAbility(kind); refresh(); };
  const startWave = () => { game.startWave(); refresh(); };

  return (
    <main className="game-screen">
      <header className="game-topbar">
        <div className="game-brand"><button className="icon-button subtle" onClick={onExit} title="Выйти в меню"><ArrowLeft size={18} /></button><span className="brand-sigil small">A</span><div><b>АЛТУШКА</b><small>{game.map.subtitle}</small></div></div>
        <div className="wave-heading"><small>{mode === "campaign" ? `КАМПАНИЯ · ${MAX_WAVE} ВОЛН` : "НОЧНОЙ ДВОР · БЕСКОНЕЧНО"}</small><b>{snap.waveActive ? `Волна ${snap.wave}` : snap.wave === 0 ? "Подготовка" : `Перед волной ${snap.wave + 1}`}</b></div>
        <div className="resources">
          <div className="resource lives"><Heart size={17} fill="currentColor" /><span><b>{snap.lives}</b><small>/ {snap.maxLives}</small></span></div>
          <div className="resource coins"><Coins size={18} /><b>{snap.coins.toLocaleString("ru-RU")}</b></div>
          <div className="resource score"><TrendingUp size={16} /><b>{snap.score.toLocaleString("ru-RU")}</b></div>
        </div>
        <div className="game-controls">
          <div className="speed-switch"><button className={snap.speed === 1 ? "active" : ""} onClick={() => { game.speed = 1; refresh(); }}>×1</button><button className={snap.speed === 2 ? "active" : ""} onClick={() => { game.speed = 2; refresh(); }}>×2</button><button className={snap.speed === 3 ? "active" : ""} onClick={() => { game.speed = 3; refresh(); }}>×3</button></div>
          <button className="icon-button subtle" onClick={togglePause} title="Пауза · Пробел">{snap.paused ? <Play size={18} /> : <Pause size={18} />}</button>
          <button className="icon-button subtle" onClick={() => { if (!sound) audio.start(); setSound(audio.toggle()); }} title="Звук">{sound ? <Volume2 size={18} /> : <VolumeX size={18} />}</button>
          <button className="icon-button subtle" onClick={() => { setHelp(true); if (!game.paused) game.paused = true; }} title="Как играть"><HelpCircle size={18} /></button>
        </div>
      </header>

      <div className="battle-grid">
        <aside className="hero-rail">
          <div className="rail-portrait">
            <ArtPortrait unit="altushka" alt="Алтушка" />
            <div className="rail-portrait-shade" />
            <div className="rail-name"><small>ГЕРОЙ / УР. {Math.min(20, 1 + Math.floor(snap.wave / 2))}</small><b>АЛТУШКА</b><span>«Только не на моём крыльце.»</span></div>
          </div>
          <section className="threat-panel">
            <div className="section-label"><span>{snap.waveActive ? "ТЕКУЩАЯ УГРОЗА" : "СЛЕДУЮЩАЯ ВОЛНА"}</span><b>{String(snap.waveActive ? snap.wave : snap.wave + 1).padStart(2, "0")}</b></div>
            <h3>{previewWave.name}</h3>
            <p>{previewWave.tip}</p>
            <div className="threat-list">
              {previewWave.groups.map((group, i) => {
                const enemy = ENEMIES[group.enemy];
                return <div className="threat-row" key={`${group.enemy}-${i}`} title={enemy.behavior}><span className={`enemy-glyph ${group.enemy === "boss" ? "boss" : ""}`}>{group.enemy === "boss" ? <ArtPortrait unit="boss" /> : group.enemy === "pigeons" ? <Zap size={13} /> : <ArtPortrait unit="skuf" />}</span><div><b>{enemy.name}</b><small>{enemy.tags.includes("flying") ? "полёт" : enemy.tags.includes("armor") ? "броня" : enemy.tags.includes("shield") ? "щит" : enemy.tags.includes("helmet") ? "шлем" : enemy.tags.includes("swarm") ? "толпа" : "пехота"}</small></div><strong>×{group.count}</strong></div>;
              })}
            </div>
          </section>
          <section className="rail-intel">
            <div className="section-label"><span>СВЯЗИ ДВОРА</span><Link2 size={13} /></div>
            <p><i className="link-dot violet" />Синкопа <span>замедление → +50% тяжёлого</span></p>
            <p><i className="link-dot yellow" />В голову <span>удержание → крит кота ×2</span></p>
            <p><i className="link-dot orange" />Энергетик <span>выручка → темп соседей</span></p>
          </section>
          <div className="perf-readout"><Gauge size={12} /> {snap.fps} FPS <span /> FIXED 30 TPS</div>
        </aside>

        <section className="battle-center">
          <div className="canvas-shell">
            <GameCanvas game={game} onSnapshot={setSnap} />
            <div className="canvas-location"><small>{game.map.name}</small><span>{snap.enemies} на подходе</span></div>
            {snap.pendingTower && <div className="placement-tip" role="status"><span>ВЫБРАНА {TOWERS[snap.pendingTower].name.toUpperCase()}</span><b>Нажми на свободную площадку</b><button aria-label="Отменить постройку" onClick={() => { game.pendingTower = null; refresh(); }}><X size={15} /></button></div>}
            {snap.perks.length > 0 && <div className="perk-strip">{snap.perks.map((id) => { const perk = perkById(id)!; return <span key={id} title={`${perk.name}: ${perk.description}`}><ArtPortrait unit={perk.art} /><b>{perk.name}</b></span>; })}</div>}
            {snap.boss && <div className="boss-hud"><div><span>{snap.boss.name}</span><b>ФАЗА {["I", "II", "III"][snap.boss.phase - 1]}</b></div><div className="boss-health"><i style={{ width: `${Math.max(0, snap.boss.hp / snap.boss.maxHp * 100)}%` }} /></div>{snap.boss.telegraph && <small>{snap.boss.telegraph === "slam" ? "ПРИГОТОВИЛ УДАР — БАШНИ БУДУТ ОТКЛЮЧЕНЫ" : snap.boss.telegraph === "summon" ? "ЗОВЁТ КОМПАНИЮ" : "ВПАДАЕТ В ЯРОСТЬ"}</small>}</div>}
            {snap.notice && snap.status !== "won" && snap.status !== "lost" && <div className={`battle-notice ${snap.notice.time < 0.4 ? "leaving" : ""}`}><b>{snap.notice.text}</b>{snap.notice.sub && <span>{snap.notice.sub}</span>}</div>}
            {snap.waveActive && <div className="wave-progress"><i style={{ width: `${snap.waveProgress * 100}%` }} /></div>}
            {!snap.waveActive && !snap.draft && snap.status !== "won" && snap.status !== "lost" && (
              <button className="call-wave" onClick={startWave}><span><small>{snap.wave === 0 ? "КОГДА БУДЕШЬ ГОТОВА" : `АВТОСТАРТ ЧЕРЕЗ ${Math.ceil(snap.intermission)} С`}</small><b>{snap.wave === 0 ? "НАЧАТЬ ПЕРВУЮ ВОЛНУ" : `ПОЗВАТЬ ВОЛНУ ${snap.wave + 1}`}</b></span>{snap.earlyBonus > 0 && <strong>+{snap.earlyBonus}<Coins size={13} /></strong>}<FastForward size={20} /></button>
            )}
            {snap.draft && <div className="draft-overlay"><div className="draft-heading"><small>ПОСЛЕ ПРОВЕРКИ · ВОЛНА {snap.wave}</small><h2>Двор делится находками</h2><p>Выбери одно условие этой смены. Таймер остановлен.</p></div><div className="draft-cards">{snap.draft.map((id) => { const perk = perkById(id)!; return <button key={id} className="draft-card" onClick={() => { game.choosePerk(id as PerkId); refresh(); }}><ArtPortrait unit={perk.art} /><span><small>УСЛОВИЕ СМЕНЫ</small><b>{perk.name}</b><p>{perk.description}</p><strong>ВЗЯТЬ С СОБОЙ <ArrowLeft size={14} /></strong></span></button>; })}</div></div>}
            {snap.paused && snap.status !== "won" && snap.status !== "lost" && <div className="pause-overlay"><div><small>СМЕНА ПРИОСТАНОВЛЕНА</small><h2>Пауза</h2><p>Двор подождёт. Враги — тоже.</p><button className="primary-button" onClick={togglePause}><Play size={17} /> Продолжить</button><button className="text-button" onClick={onExit}>Выйти в меню</button></div></div>}
          </div>

          <div className="ability-dock">
            <div className="ability-hero"><Crosshair size={16} /><span>СПОСОБНОСТИ<small>Выбери, затем укажи место</small></span></div>
            {(Object.keys(ABILITIES) as (keyof typeof ABILITIES)[]).map((kind) => {
              const ability = ABILITIES[kind];
              const cd = snap.cooldowns[kind];
              const ratio = cd / ability.cooldown;
              return <button key={kind} className={`ability-button ${snap.targeting === kind ? "targeting" : ""}`} disabled={cd > 0 || !snap.waveActive || snap.paused} onClick={() => arm(kind)} title={ability.description}>
                <span className="ability-icon" style={{ "--cooldown": `${ratio * 360}deg` } as React.CSSProperties}>{kind === "bucket" ? <CloudRain /> : kind === "chord" ? <AudioLines /> : <Cat />}{cd > 0 && <b>{Math.ceil(cd)}</b>}</span>
                <span><small>{ability.key}</small><b>{ability.name}</b></span>
              </button>;
            })}
            {snap.targeting && <button className="cancel-target" onClick={() => { game.targeting = null; refresh(); }}><X size={15} /> Отмена</button>}
          </div>

          <div className="build-dock">
            <div className="build-tabs"><button className={tab === "people" ? "active" : ""} onClick={() => setTab("people")}><Users size={15} /> Жители</button><button className={tab === "props" ? "active" : ""} onClick={() => setTab("props")}><Sofa size={15} /> Живой двор</button></div>
            <div className="build-cards">
              {tab === "people" ? towerIds.map((id, index) => {
                const tower = TOWERS[id];
                const canPlace = selectedPad !== null && snap.unlockedPads.includes(selectedPad.id) && !snap.towers.some((t) => t.pad === selectedPad.id);
                return <button key={id} className={`build-card ${snap.pendingTower === id ? "chosen" : ""} ${snap.coins < tower.cost ? "poor" : ""}`} onClick={() => build(id)} title={`${canPlace ? "Построить" : "Выбрать и указать площадку"} · ${tower.description}`} aria-label={`${tower.name}, ${tower.cost} монет`}>
                  <ArtPortrait unit={id} /><span className="build-card-copy"><small>0{index + 1} / {damageNames[tower.damageType]}</small><b>{tower.name}</b><span><Coins size={11} />{tower.cost}</span></span><kbd>{index + 1}</kbd>
                </button>;
              }) : (Object.keys(PROP_DATA) as PropId[]).map((id) => {
                const prop = PROP_DATA[id];
                const allowed = selectedSpot?.allowed.includes(id) && !snap.props.some((p) => p.spot === selectedSpot.id);
                return <button key={id} className={`build-card prop-card ${!allowed ? "unavailable" : ""} ${snap.coins < prop.cost ? "poor" : ""}`} onClick={() => { if (snap.selectedSpot !== null) game.buildProp(snap.selectedSpot, id); refresh(); }} title={prop.description}>
                  <span className="prop-art">{propIcons[id]}</span><span className="build-card-copy"><small>ОБЪЕКТ ДВОРА</small><b>{prop.name}</b><span><Coins size={11} />{prop.cost}</span></span>
                </button>;
              })}
            </div>
          </div>
        </section>

        <aside className="inspector">
          <div className="inspector-top"><span>{selectedTower ? "КАРТОЧКА ЖИТЕЛЯ" : snap.selectedProp ? "ОБЪЕКТ ДВОРА" : selectedSpot ? "МЕСТО ДЛЯ ОБЪЕКТА" : "ПЛОЩАДКА"}</span><MousePointer2 size={13} /></div>
          {selectedTower && selectedStats ? (
            <div className="tower-inspector">
              <div className="inspector-person"><ArtPortrait unit={selectedTower.type} alt={TOWERS[selectedTower.type].name} /><div><small>{TOWERS[selectedTower.type].role}</small><h2>{TOWERS[selectedTower.type].name}</h2><span>УРОВЕНЬ {selectedTower.level} {selectedTower.branch !== null && `· ${TOWERS[selectedTower.type].branches[selectedTower.branch].name}`}</span></div></div>
              <div className="level-track">{[1, 2, 3, 4].map((level) => <i key={level} className={level <= selectedTower.level ? "filled" : ""} />)}</div>
              <div className="upgrade-zone">
                {selectedTower.level < 4 && <div className="section-label"><span>{selectedTower.level === 2 ? "ВЫБЕРИ ВЕТКУ УЛУЧШЕНИЯ" : "УЛУЧШЕНИЕ ЖИТЕЛЯ"}</span><b><Coins size={12} /> {game.upgradeCost(selectedTower)}</b></div>}
                {selectedTower.level === 2 ? TOWERS[selectedTower.type].branches.map((branch, index) => <button className={`branch-button ${snap.coins < game.upgradeCost(selectedTower) ? "insufficient" : ""}`} key={branch.id} onClick={() => { game.upgradeTower(selectedTower.uid, index as 0 | 1); refresh(); }}><span>0{index + 1}</span><div><b>{branch.name}</b><p>{branch.description}</p></div><strong>{game.upgradeCost(selectedTower)}</strong></button>) : selectedTower.level < 4 ? <button className={`upgrade-button ${snap.coins < game.upgradeCost(selectedTower) ? "insufficient" : ""}`} onClick={() => { game.upgradeTower(selectedTower.uid); refresh(); }}><ChevronUp size={17} /><span>{selectedTower.level === 3 ? "Открыть капстоун" : `Улучшить до уровня ${selectedTower.level + 1}`}</span><b>{game.upgradeCost(selectedTower)}</b></button> : <div className="capstone-card"><Star size={16} fill="currentColor" /><div><small>КАПСТОУН ОТКРЫТ</small><b>{selectedTower.branch !== null ? TOWERS[selectedTower.type].branches[selectedTower.branch].capstone : "Максимальный уровень"}</b></div></div>}
                {selectedTower.level < 4 && snap.coins < game.upgradeCost(selectedTower) && <p className="money-hint">Не хватает {game.upgradeCost(selectedTower) - snap.coins} монет. Защищай двор, чтобы заработать.</p>}
              </div>
              <p className="inspector-description">{TOWERS[selectedTower.type].description}</p>
              {selectedTower.type === "kiosk" ? <div className="economy-card"><Coins size={20} /><div><b>Следующая выручка через {Math.max(0, selectedTower.cooldown).toFixed(1)} с</b><span>Базовый цикл 8 с · соседи получают темп</span></div></div> : <div className="stat-grid"><div><small>УРОН</small><b>{selectedStats.damage.toFixed(0)}</b></div><div><small>ТЕМП / С</small><b>{selectedStats.rate.toFixed(2)}</b></div><div><small>DPS</small><b>{(selectedStats.damage * selectedStats.rate).toFixed(1)}</b></div><div><small>РАДИУС</small><b>{selectedStats.range.toFixed(0)}</b></div></div>}
              <div className="run-stats"><span><Swords size={12} /> {Math.round(selectedTower.damageDone).toLocaleString("ru-RU")} урона</span><span><Check size={12} /> {selectedTower.kills} побед</span></div>
              {selectedTower.type !== "kiosk" && <div className="inspector-section"><div className="section-label"><span>ПРИОРИТЕТ ЦЕЛИ</span><Crosshair size={12} /></div><div className="target-modes">{targetModes.map((target) => <button key={target.id} title={target.name} className={selectedTower.targetMode === target.id ? "active" : ""} onClick={() => { game.setTargetMode(selectedTower.uid, target.id); refresh(); }}>{target.short}</button>)}</div></div>}
              {activeLinks.length > 0 && <div className="active-links"><div className="section-label"><span>АКТИВНЫЕ СВЯЗИ</span><Link2 size={12} /></div>{activeLinks.map((link, i) => <p key={i} style={{ color: link.color }}><i />{link.name}<span>{link.name === "СИНКОПА" ? "+50% по замедленным" : link.name === "В ГОЛОВУ" ? "крит по удерживаемым" : "темп после выплаты"}</span></p>)}</div>}
              <button className="sell-button" onClick={() => { game.sellTower(selectedTower.uid); refresh(); }}><Trash2 size={14} /> Отпустить жителя <span>+{Math.floor(selectedTower.invested * 0.7)} <Coins size={11} /></span></button>
            </div>
          ) : snap.selectedProp ? (
            <div className="prop-inspector"><div className="prop-large-icon">{propIcons[snap.selectedProp.type]}</div><h2>{PROP_DATA[snap.selectedProp.type].name}</h2><p>{PROP_DATA[snap.selectedProp.type].description}</p><div className="prop-hp"><span>ПРОЧНОСТЬ <b>{Math.ceil(snap.selectedProp.hp)} / {snap.selectedProp.maxHp}</b></span><div><i style={{ width: `${snap.selectedProp.hp / snap.selectedProp.maxHp * 100}%` }} /></div></div><button className="sell-button" onClick={() => { game.removeProp(snap.selectedProp!.uid); refresh(); }}><Trash2 size={14} /> Убрать объект <span>часть стоимости</span></button></div>
          ) : selectedSpot ? (
            <div className="empty-inspector"><div className="empty-pad-icon"><Sofa /></div><small>ТОЧКА {selectedSpot.id + 1}</small><h2>Оживить двор</h2><p>Здесь можно поставить: {selectedSpot.allowed.map((id) => PROP_DATA[id].name.toLowerCase()).join(" или ")}. Выбери объект в нижней панели «Живой двор».</p><div className="allowed-props">{selectedSpot.allowed.map((id) => <span key={id}>{propIcons[id]}{PROP_DATA[id].name}</span>)}</div><button className="primary-button" onClick={() => setTab("props")}>Выбрать объект</button></div>
          ) : selectedPad ? (
            <div className="empty-inspector">
              {!snap.unlockedPads.includes(selectedPad.id) ? <><div className="empty-pad-icon locked"><LockKeyhole /></div><small>ПЛОЩАДКА {selectedPad.id + 1} · ЗАКРЫТА</small><h2>{snap.wave >= selectedPad.unlockWave ? "Расчистить место" : `Откроется после волны ${selectedPad.unlockWave}`}</h2><p>Новые площадки — главный предел твоей сборки. Соседние связи появятся автоматически.</p><button className="upgrade-button" disabled={snap.wave < selectedPad.unlockWave || snap.coins < selectedPad.unlockCost} onClick={() => { game.unlockPad(selectedPad.id); refresh(); }}><LockKeyhole size={16} /><span>Расчистить площадку</span><b>{selectedPad.unlockCost}</b></button></> : <><div className="empty-pad-icon"><Users /></div><small>ПЛОЩАДКА {selectedPad.id + 1} · СВОБОДНА</small><h2>Кого позовём?</h2><p>Выбери жителя в нижней панели. Поставить или улучшать можно и между волнами, и во время боя.</p><div className="pad-neighbors"><div className="section-label"><span>СОСЕДНИЕ ПЛОЩАДКИ</span><Link2 size={12} /></div>{game.map.pads.filter((p) => game.areNeighbors(p.id, selectedPad.id)).map((pad) => { const neighbor = snap.towers.find((t) => t.pad === pad.id); return <p key={pad.id}><span>#{pad.id + 1}</span>{neighbor ? TOWERS[neighbor.type].name : "свободна"}</p>; })}</div></>}
            </div>
          ) : <div className="empty-inspector"><div className="empty-pad-icon"><MousePointer2 /></div><h2>Выбери площадку</h2><p>Нажми на круг на игровом поле, чтобы построить или осмотреть жителя.</p></div>}
          <div className="inspector-wave-card"><div><small>{snap.waveActive ? "ХОД ВОЛНЫ" : "ДАЛЬШЕ"}</small><b>{snap.waveActive ? `${Math.round(snap.waveProgress * 100)}%` : `Волна ${snap.wave + 1}`}</b></div><p>{previewWave.name}</p><span>{previewWave.groups.reduce((sum, g) => sum + g.count, 0)} противников · награда {previewWave.bonus}</span></div>
        </aside>
      </div>

      {(snap.status === "won" || snap.status === "lost") && <div className="result-overlay"><section className="result-card"><div className="result-art"><ArtPortrait unit={snap.status === "won" ? "altushka" : "skuf"} /></div><div className="result-copy"><small>{snap.status === "won" ? "РАССВЕТ · СМЕНА ОКОНЧЕНА" : `КОНЕЦ СМЕНЫ · ВОЛНА ${snap.wave}`}</small><h2>{snap.status === "won" ? "Двор остался нашим" : "Подъезд захвачен"}</h2><p>{snap.status === "won" ? "Кто-то уже вешает бельё. Кто-то делает вид, что не боялся. Ты просто ставишь гитару в угол." : "Сборка не выдержала. Попробуй другой контрпик, связку соседей или ранний вызов ради монет."}</p>{snap.status === "won" && <div className="result-stars">{[0, 1, 2].map((star) => <Star key={star} size={30} fill={star < snap.starsEarned ? "currentColor" : "none"} />)}</div>}<div className="result-stats"><div><small>СЧЁТ</small><b>{snap.score.toLocaleString("ru-RU")}</b></div><div><small>ВОЛНА</small><b>{snap.wave}</b></div><div><small>HP ПОДЪЕЗДА</small><b>{snap.lives}</b></div></div><div className="result-actions"><button className="primary-button" onClick={onRestart}><RotateCcw size={17} /> Ещё смена</button><button className="secondary-button" onClick={onExit}><Home size={17} /> Во дворы</button></div></div></section></div>}

      {help && <div className="modal-backdrop" onMouseDown={() => setHelp(false)}><section className="help-modal" onMouseDown={(e) => e.stopPropagation()}><header><div><small>ПОЛЕВОЕ РУКОВОДСТВО</small><h2>Как удержать двор</h2></div><button className="icon-button" onClick={() => setHelp(false)}><X /></button></header><div className="help-grid"><article><Shield /><h3>Контри состав</h3><p>Шлемы гасят мягкий урон Подруги. Броню пробивает Кот. Щиты разбирает тяжёлый урон Бабы Вали. По стаям тяжёлые атаки слабы.</p></article><article><Link2 /><h3>Соединяй соседей</h3><p>У каждой площадки до двух соседей. Динамик + Баба Валя, Дозорный + Кот и Киоск + любая боевая башня создают работающие связи.</p></article><article><Timer /><h3>Рискуй ради монет</h3><p>Досрочный вызов даёт монеты за оставшееся время. Третий уровень требует выбрать ветку, четвёртый открывает уникальный капстоун.</p></article><article><MousePointer2 /><h3>Управление</h3><p>1–6 — построить · F — волна · Q/W/E — способность · Пробел — пауза · 0 — скорость · Esc — отмена.</p></article></div><button className="primary-button" onClick={() => { setHelp(false); game.paused = false; refresh(); }}><Play size={16} /> Понятно, в бой</button></section></div>}
    </main>
  );
}
