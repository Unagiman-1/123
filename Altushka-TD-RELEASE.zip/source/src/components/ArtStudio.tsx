import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { Check, ChevronRight, ImagePlus, LockKeyhole, Pause, Play, RotateCcw, Upload, X } from "lucide-react";
import { getArtwork, getArtVersion, importArtwork, resetArtwork, subscribeArt } from "../game/art-library";
import { ART_NAMES, ART_UNITS, type ArtUnit, type BackgroundKey, type MotionKind } from "../game/art-types";
import { ArtPortrait, SourceFigure } from "./SourceFigure";

export function ArtStudio({ onClose }: { onClose: () => void }) {
  const [unit, setUnit] = useState<ArtUnit>("altushka");
  const [motion, setMotion] = useState<MotionKind>("idle");
  const [playing, setPlaying] = useState(true);
  const [compare, setCompare] = useState(false);
  const [key, setKey] = useState<BackgroundKey>("auto");
  const [fullBody, setFullBody] = useState(false);
  const [progress, setProgress] = useState(0);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [dragging, setDragging] = useState(false);
  const dialog = useRef<HTMLElement>(null);
  const input = useRef<HTMLInputElement>(null);
  useSyncExternalStore(subscribeArt, getArtVersion);
  const art = getArtwork(unit);
  // Два сидящих оригинала не подходят для цикла шага, даже если они в полный рост.
  const canWalk = art.fullBody && (art.source !== "builtin" || (unit !== "cat" && unit !== "kiosk"));

  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    dialog.current?.focus();
    const close = (event: KeyboardEvent) => {
      if (event.key === "Escape" && !busy) { event.stopPropagation(); onClose(); }
      if (event.key === "Tab") {
        const focusable = dialog.current?.querySelectorAll<HTMLElement>('button:not(:disabled), input:not([hidden]), select, [tabindex="0"]');
        if (!focusable?.length) return;
        const first = focusable[0], last = focusable[focusable.length - 1];
        if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog.current)) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    };
    window.addEventListener("keydown", close, true);
    return () => { window.removeEventListener("keydown", close, true); previous?.focus(); };
  }, [onClose, busy]);

  const select = (next: ArtUnit) => { setUnit(next); setMessage(""); setError(""); setMotion("idle"); setFullBody(false); };
  const upload = async (file?: File) => {
    if (!file || busy) return;
    setBusy(true); setError(""); setMessage("");
    try {
      const result = await importArtwork(unit, file, key, fullBody);
      setMessage(result.persisted ? "Исходник применён и сохранён на этом устройстве." : "Применено на эту сессию. Браузер не разрешил локальное сохранение.");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Не удалось прочитать изображение."); }
    finally { setBusy(false); if (input.current) input.current.value = ""; }
  };
  const reset = async () => {
    setBusy(true); setError("");
    try { await resetArtwork(unit); setMessage("Восстановлен арт из проекта."); setMotion("idle"); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Не удалось сбросить арт."); }
    finally { setBusy(false); }
  };

  return (
    <div className="art-studio-backdrop">
      <section className="art-studio" ref={dialog} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby="studio-title">
        <header className="studio-header">
          <div className="studio-title"><span className="brand-sigil small">A</span><div><small>ALTUSHKA / ИСХОДНЫЙ АРТ</small><h2 id="studio-title">Арты и анимация</h2></div></div>
          <span className="studio-camera"><LockKeyhole size={12} /> Камера закреплена</span>
          <button className="icon-button" aria-label="Закрыть арт-студию" disabled={busy} onClick={onClose}><X size={19} /></button>
        </header>
        <div className="studio-layout">
          <nav className="studio-roster" aria-label="Персонажи для настройки">
            <small>ЖИТЕЛИ И ГОСТИ</small>
            {ART_UNITS.map((id, index) => <button key={id} disabled={busy} className={unit === id ? "selected" : ""} onClick={() => select(id)}><ArtPortrait unit={id} /><span><small>{String(index + 1).padStart(2, "0")} / {id === "altushka" ? "ГЕРОЙ" : id === "boss" || id === "skuf" ? "ПРОТИВНИК" : "ЖИТЕЛЬ"}</small><b>{ART_NAMES[id]}</b></span><ChevronRight size={13} /></button>)}
          </nav>
          <div className="studio-viewer">
            <div className="studio-view-heading"><div><small>{art.source === "uploaded" ? "ВАШ ОРИГИНАЛ" : "АРТ ИЗ ПРОЕКТА"}</small><h3>{ART_NAMES[unit]}</h3></div><button className={`studio-compare ${compare ? "active" : ""}`} onClick={() => setCompare(!compare)}>{compare ? <Check size={13} /> : <ImagePlus size={13} />} Сравнить с исходником</button></div>
            <div className={`studio-stage ${compare ? "comparing" : ""}`}>
              {compare && <div className="studio-reference"><small>ИСХОДНЫЙ АРТ</small><img src={art.originalUrl} alt={`Оригинал: ${ART_NAMES[unit]}`} /></div>}
              <div className="studio-animated"><small>{motion === "neutral" ? "БЕЗ ДВИЖЕНИЯ И ФИЛЬТРОВ" : "АНИМАЦИЯ ИСХОДНОЙ ТЕКСТУРЫ"}</small><SourceFigure unit={unit} motion={motion} playing={playing} progress={progress} /></div>
            </div>
            <div className="studio-playback"><button className="icon-button" aria-label={playing ? "Приостановить анимацию" : "Воспроизвести анимацию"} onClick={() => setPlaying(!playing)}>{playing ? <Pause size={16} /> : <Play size={16} />}</button><div className="studio-motion" role="group" aria-label="Режим анимации">{([['idle', 'Покой'], ['attack', 'Отклик атаки'], ['walk', 'Шаг'], ['neutral', 'Исходник']] as const).map(([id, label]) => <button key={id} className={motion === id ? "active" : ""} disabled={id === "walk" && !canWalk} title={id === "walk" && !canWalk ? "Для шага нужен стоящий персонаж в полный рост" : undefined} onClick={() => setMotion(id)}>{label}</button>)}</div><label className="studio-scrub"><span>КАДР</span><input aria-label="Кадр анимации" type="range" min="0" max="1" step="0.01" value={progress} onChange={(event) => { setPlaying(false); setProgress(Number(event.target.value)); }} /></label></div>
            <p className="studio-framing-note">{art.fullBody ? "Полнофигурный исходник. Кадрирование сохранено; отсутствующие ракурсы не генерируются." : "Исходник обрезан. Недостающие ноги и части одежды не дорисовываются; цикл шага отключён."}</p>
          </div>
          <aside className="studio-settings">
            <div className="studio-source-label"><i /> ТОЛЬКО ИСХОДНЫЙ АРТ</div>
            <h3>Не похожий.<br />Именно твой.</h3>
            <p>Загрузи оригинал для этого персонажа. Он заменит арт в меню, карточках и на игровом поле без перерисовки лица и костюма.</p>
            <div className="studio-file-info"><span>ИСТОЧНИК</span><b title={art.filename}>{art.filename}</b><small>{art.width} × {art.height} / {art.source === "uploaded" ? "локальный файл" : "исходник проекта"}</small></div>
            <label className="studio-select"><span>ФОН НОВОГО ФАЙЛА</span><select value={key} onChange={(event) => setKey(event.target.value as BackgroundKey)}><option value="auto">Авто / прозрачный или белый</option><option value="none">Не удалять фон</option><option value="white">Удалить белый у края</option><option value="black">Удалить чёрный у края</option></select></label>
            <label className="studio-fullbody"><input type="checkbox" checked={fullBody} onChange={(event) => setFullBody(event.target.checked)} /><span>Новый файл показывает персонажа в полный рост</span></label>
            <div className={`studio-drop ${dragging ? "dragging" : ""}`} onDragOver={(event) => { event.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={(event) => { event.preventDefault(); setDragging(false); void upload(event.dataTransfer.files[0]); }}>
              <Upload size={22} /><b>{busy ? "Подготовка исходника…" : "Перетащи оригинал сюда"}</b><span>PNG с альфа-каналом предпочтительнее<br />JPEG / WebP · до 20 МБ</span>
              <button className="primary-button" disabled={busy} onClick={() => input.current?.click()}>Выбрать файл</button>
              <input ref={input} type="file" accept="image/png,image/jpeg,image/webp" aria-label="Загрузить оригинал персонажа" onChange={(event) => void upload(event.target.files?.[0])} hidden />
            </div>
            {message && <p className="studio-message" role="status"><Check size={14} />{message}</p>}
            {error && <p className="studio-error" role="alert">{error}</p>}
            <button className="studio-reset" disabled={busy || art.source !== "uploaded"} onClick={() => void reset()}><RotateCcw size={13} /> Вернуть арт проекта</button>
            <p className="studio-honesty">Это 2D-анимация исходного изображения, не 3D-модель. Для бега и ударов с новыми ракурсами нужны полнофигурные кадры или готовая модель.</p>
          </aside>
        </div>
        <footer className="studio-footer"><span>БЕЗ ГЕНЕРАЦИИ ЛИЦ И ОДЕЖДЫ</span><span>Файлы хранятся только в этом браузере. На сервер не отправляются.</span></footer>
      </section>
    </div>
  );
}