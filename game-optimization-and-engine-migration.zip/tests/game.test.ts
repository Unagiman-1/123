import { test } from "node:test";
import assert from "node:assert/strict";
import { Game } from "../src/game/engine";
import { MAPS, TOWERS } from "../src/game/data";
import type { TowerId } from "../src/game/types";

test("a character can be chosen first and placed during a wave", () => {
  const game = new Game("yard", "campaign", 42);
  assert.equal(game.prepareTower("girlfriend"), true);
  assert.equal(game.coins, 200);
  game.startWave();
  assert.equal(game.status, "wave");
  assert.equal(game.prepareTower("granny"), true);
  assert.equal(game.pendingTower, "granny");
  assert.equal(game.coins, 200);
  game.selectAt(390, 345);
  assert.equal(game.towers.length, 2);
  assert.equal(game.selectedTower?.type, "granny");
  assert.equal(game.coins, 90);
  assert.equal(game.pendingTower, null);
  assert.equal(game.upgradeTower(game.selectedTower!.uid), true);
  assert.equal(game.selectedTower?.level, 2);
  assert.equal(game.coins, 29);
});

test("the entire standing character can be selected, not only the ground marker", () => {
  const game = new Game("yard", "campaign", 2);
  game.buildTower(0, "girlfriend");
  game.selectAt(0, 0);
  assert.equal(game.selectedTower, null);
  assert.equal(game.selectAt(220, 170), "pad");
  assert.equal(game.selectedTower?.type, "girlfriend");
});

for (const type of Object.keys(TOWERS) as TowerId[]) {
  for (const branch of [0, 1] as const) {
    test(`${type} can upgrade through branch ${branch} during combat`, () => {
      const game = new Game("yard", "campaign", 7);
      game.coins = 10000;
      assert.equal(game.buildTower(2, type), true);
      const tower = game.selectedTower!;
      game.startWave();
      assert.equal(game.upgradeTower(tower.uid), true);
      const coinsBeforeChoice = game.coins;
      assert.equal(game.upgradeTower(tower.uid), false);
      assert.equal(game.coins, coinsBeforeChoice);
      assert.equal(game.upgradeTower(tower.uid, branch), true);
      assert.equal(game.upgradeTower(tower.uid), true);
      assert.equal(tower.level, 4);
      assert.equal(tower.branch, branch);
    });
  }
}

test("failed purchases and upgrades explain the missing funds", () => {
  const game = new Game("yard", "campaign", 3);
  game.coins = 0;
  assert.equal(game.prepareTower("granny"), false);
  assert.match(game.notice!.sub, /110/);
  game.coins = TOWERS.girlfriend.cost;
  assert.equal(game.buildTower(0, "girlfriend"), true);
  const tower = game.selectedTower!;
  assert.equal(game.upgradeTower(tower.uid), false);
  assert.equal(tower.level, 1);
  assert.match(game.notice!.sub, /39/);
});

test("every open pad is selectable on all maps", () => {
  for (const map of MAPS) {
    const game = new Game(map.id, "campaign", 11);
    for (const pad of map.pads.filter((item) => item.unlockWave === 0)) {
      game.selectAt(pad.x, pad.y);
      assert.equal(game.selectedPad, pad.id, `${map.id} pad ${pad.id}`);
    }
  }
});

test("walking state follows movement and stops under crowd control", () => {
  const game = new Game("yard", "campaign", 12);
  game.startWave();
  const enemy = game.spawnEnemy("skuf", 0, 100);
  game.update(1 / 30);
  assert.equal(enemy.walking, true);
  const position = enemy.progress;
  enemy.stunUntil = game.time + 2;
  game.update(1 / 30);
  assert.equal(enemy.walking, false);
  assert.equal(enemy.progress, position);
});

test("defeated enemies create a short fading animation without blocking the wave", () => {
  const game = new Game("yard", "campaign", 5);
  const enemy = game.spawnEnemy("skuf", 0, 150);
  game.killEnemy(enemy, null);
  assert.equal(game.fadingActors.length, 1);
  for (let i = 0; i < 30; i++) game.update(1 / 30);
  assert.equal(game.fadingActors.length, 0);
});

test("an actual wave spawns enemies, pays rewards and returns to preparation", () => {
  const game = new Game("yard", "campaign", 37);
  game.coins = 5000;
  for (const pad of [0, 2, 4, 5, 6, 7]) {
    assert.equal(game.buildTower(pad, "cat"), true);
    assert.equal(game.upgradeTower(game.selectedTower!.uid), true);
  }
  game.startWave();
  const coinsAtStart = game.coins;
  for (let i = 0; i < 30 * 100 && game.waveActive; i++) game.update(1 / 30);
  assert.equal(game.status, "prep");
  assert.equal(game.wave, 1);
  assert.ok(game.coins > coinsAtStart);
  assert.ok(game.score > 0);
});