# Алтушка TD — Phaser 4 + React + Vite

Tower defense «Двор не сдаётся».

- **Движок поля боя:** Phaser 4 (`src/phaser/BattleScene.ts`) — спрайты, камера с тряской, ввод, фиксированный шаг симуляции 30 Гц.
- **Интерфейс:** React 19 + Tailwind CSS 4 (меню, HUD, карточки, инспектор).
- **Логика:** чистый TypeScript без зависимостей от рендера (`src/game/engine.ts`, `data.ts`, `perks.ts`, `meta.ts`, `audio.ts`).
- **Персонажи:** оригинальные арты в `public/art/units/` (`source-*.webp`).

## Запуск

```sh
npm install
npm run dev      # разработка, http://localhost:5173
npm run build    # production-сборка в dist/
npm test         # тесты логики боя
```

## Структура

```
src/
  App.tsx                 — переключение меню / игры
  components/
    MainMenu.tsx          — главное меню, выбор карты и режима
    GameScreen.tsx        — HUD поверх игрового поля
    GameCanvas.tsx        — монтирует Phaser-игру в React
    ArtPortrait.tsx       — портрет персонажа из public/art/units
  phaser/BattleScene.ts   — отрисовка и ввод игрового поля
  game/                   — логика игры (без UI)
public/art/units/         — оригинальные арты персонажей
tests/game.test.ts        — тесты логики боя
```
