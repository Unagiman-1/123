import { useCallback, useState } from "react";
import { MainMenu } from "./components/MainMenu";
import { GameScreen } from "./components/GameScreen";
import { loadMeta, recordRun } from "./game/meta";
import type { GameMode } from "./game/types";

interface RunConfig { mapId: string; mode: GameMode; seed: number }

export default function App() {
  const [meta, setMeta] = useState(loadMeta);
  const [run, setRun] = useState<RunConfig | null>(null);
  const [runId, setRunId] = useState(0);

  const start = (mapId: string, mode: GameMode, seed: number) => {
    setRun({ mapId, mode, seed });
    setRunId((id) => id + 1);
  };

  const complete = useCallback((result: { wave: number; score: number; stars: number }) => {
    if (run) setMeta((previous) => recordRun(previous, run.mapId, result.wave, result.score, result.stars));
  }, [run]);

  if (!run) return <MainMenu meta={meta} onStart={start} />;
  return (
    <GameScreen
      key={runId}
      mapId={run.mapId}
      mode={run.mode}
      seed={run.seed}
      onExit={() => setRun(null)}
      onRestart={() => { setRun({ ...run, seed: run.mode === "campaign" ? Date.now() & 0xffffffff : run.seed }); setRunId((id) => id + 1); }}
      onComplete={complete}
    />
  );
}
