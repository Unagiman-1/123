import { ArtPortrait } from "./ArtPortrait";

export function LiveHero() {
  return (
    <div className="live-hero-doll">
      <ArtPortrait unit="altushka" alt="Алтушка" className="source-figure" />
    </div>
  );
}
