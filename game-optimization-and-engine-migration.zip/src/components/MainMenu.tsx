import { useState } from "react";
import { ArrowRight, BookOpen, Infinity as InfinityIcon, LockKeyhole, Play, Star, Users, Volume2, VolumeX, X } from "lucide-react";
import { MAPS, TOWERS } from "../game/data";
import { audio } from "../game/audio";
import { dailySeed, type MetaState } from "../game/meta";
import type { GameMode } from "../game/types";
import { LiveHero } from "./LiveHero";
import { ArtPortrait } from "./ArtPortrait";

export function MainMenu({ meta, onStart }: { meta: MetaState; onStart: (mapId: string, mode: GameMode, seed: number) => void }) {
  const [mapId, setMapId] = useState("yard");
  const [mode, setMode] = useState<GameMode>("campaign");
  const [codex, setCodex] = useState(false);
  const [sound, setSound] = useState(audio.isEnabled);
  const map = MAPS.find((item) => item.id === mapId) ?? MAPS[0];
  const daily = dailySeed();

  const start = async () => {
    await audio.start();
    onStart(mapId, mode, mode === "endless" ? daily.seed : (Date.now() & 0xffffffff));
  };

  return (
    <main className="menu-screen">
      <div className="menu-backdrop" />
      <div className="menu-grain" />
      <header className="menu-header">
        <div className="brand-mark"><span className="brand-sigil">A</span><span>ALTUSHKA<br /><b>TOWER DEFENSE</b></span></div>
        <div className="menu-header-center">СЕВЕРНЫЙ РАЙОН <i /> 03:47 <i /> СМЕНА {String(meta.runs + 1).padStart(2, "0")}</div>
        <div className="menu-actions">
          <button className="text-button" onClick={() => setCodex(true)}><Users size={16} /> Жители</button>
          <button className="icon-button" aria-label={sound ? "Выключить звук" : "Включить звук"} onClick={() => { if (!sound) audio.start(); setSound(audio.toggle()); }}>{sound ? <Volume2 size={18} /> : <VolumeX size={18} />}</button>
        </div>
      </header>

      <section className="menu-hero">
        <div className="menu-copy">
          <div className="eyebrow"><span /> ЖИВОЙ ДВОР / ПЕРЕДЕЛКА 2.0</div>
          <h1>АЛТУШКА</h1>
          <div className="title-sub"><b>TOWER DEFENSE</b><span>Двор помнит каждого,<br />кого ты не впустила.</span></div>
          <p className="menu-quote">«Они пришли за тишиной.<br />Плохой адрес.»</p>
        </div>
        <div className="menu-altushka" aria-label="Алтушка: исходный арт">
          <div className="portrait-halo" />
          <LiveHero />
          <div className="hero-caption"><span>ГЕРОЙ / 01</span><b>АЛТУШКА</b><small>Двор на месте. Смена продолжается.</small></div>
        </div>
        <div className="menu-side-note"><span>20</span><p>авторских<br />волн</p><i /><span>12</span><p>характеров<br />врагов</p></div>
      </section>

      <section className="run-setup">
        <div className="mode-switch" role="group" aria-label="Режим игры">
          <button className={mode === "campaign" ? "active" : ""} onClick={() => setMode("campaign")}><Play size={15} /> Кампания <small>20 волн</small></button>
          <button className={mode === "endless" ? "active" : ""} onClick={() => setMode("endless")}><InfinityIcon size={17} /> Ночной двор <small>сид дня</small></button>
        </div>
        <div className="map-selector">
          {MAPS.map((item, index) => {
            const locked = meta.totalStars < item.requiredStars;
            const record = meta.records[item.id];
            return (
              <button key={item.id} disabled={locked} className={`map-card ${mapId === item.id ? "selected" : ""}`} onClick={() => setMapId(item.id)}>
                <div className={`map-thumb map-thumb-${index}`}><span className="map-route" />{locked && <LockKeyhole size={20} />}<b>0{index + 1}</b></div>
                <div className="map-card-copy"><small>{item.subtitle}</small><strong>{item.name}</strong>
                  <span className="map-stars">{locked ? `НУЖНО ${item.requiredStars} ★` : [0, 1, 2].map((star) => <Star key={star} size={12} fill={star < (record?.stars ?? 0) ? "currentColor" : "none"} />)}</span>
                </div>
              </button>
            );
          })}
        </div>
        <div className="launch-block">
          <div className="selected-map-info"><small>{mode === "campaign" ? "ВЫБРАННАЯ СМЕНА" : `СИД ДНЯ · ${daily.label}`}</small><b>{map.name}</b><p>{map.description}</p></div>
          <button className="launch-button" onClick={start}><span>{mode === "campaign" ? "ВОЙТИ ВО ДВОР" : "НАЧАТЬ НОЧЬ"}</span><ArrowRight size={22} /></button>
          <div className="meta-line"><Star size={13} fill="currentColor" /> {meta.totalStars} звёзд собрано <span /> лучший счёт {Math.max(0, ...Object.values(meta.records).map((r) => r.bestScore)).toLocaleString("ru-RU")}</div>
        </div>
      </section>

      <footer className="menu-footer"><span>ФИКСИРОВАННАЯ СИМУЛЯЦИЯ · 30 TPS</span><span>Q / W / E — СПОСОБНОСТИ</span><span>ПРОБЕЛ — ПАУЗА</span></footer>

      {codex && (
        <div className="modal-backdrop" onMouseDown={() => setCodex(false)}>
          <section className="codex-modal" onMouseDown={(e) => e.stopPropagation()}>
            <header><div><small>ЛЮДИ, КОТОРЫЕ НЕ СДАЮТСЯ</small><h2>Жители двора</h2></div><button className="icon-button" onClick={() => setCodex(false)}><X /></button></header>
            <div className="codex-grid">
              {Object.values(TOWERS).map((tower) => (
                <article className="codex-person" key={tower.id}>
                  <ArtPortrait unit={tower.id} alt={tower.name} />
                  <div><small>{tower.role}</small><h3>{tower.name}</h3><p>{tower.description}</p><span>{tower.cost} монет · {tower.branches[0].name} / {tower.branches[1].name}</span></div>
                </article>
              ))}
            </div>
            <div className="codex-tip"><BookOpen size={18} /><p><b>Соседние связи.</b> Динамик усиливает Бабу Валю по замедленным, Дозорный даёт коту криты по удерживаемым, а выплата киоска ускоряет соседние башни.</p></div>
          </section>
        </div>
      )}
    </main>
  );
}
