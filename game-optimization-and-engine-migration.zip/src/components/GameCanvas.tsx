import { useEffect, useRef } from "react";
import Phaser from "phaser";
import { LOGICAL_HEIGHT, LOGICAL_WIDTH } from "../game/data";
import type { Game } from "../game/engine";
import type { Snapshot } from "../game/types";
import { BattleScene } from "../phaser/BattleScene";

/** Монтирует Phaser-игру в React. Состояние боя и UI-снимки передаются наружу через колбэк. */
export function GameCanvas({ game, onSnapshot }: { game: Game; onSnapshot: (snapshot: Snapshot) => void }) {
  const hostRef = useRef<HTMLDivElement>(null);
  const snapshotRef = useRef(onSnapshot);
  snapshotRef.current = onSnapshot;

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    const scene = new BattleScene({ game, onSnapshot: (snapshot) => snapshotRef.current(snapshot) });
    const instance = new Phaser.Game({
      type: Phaser.AUTO,
      parent: host,
      width: LOGICAL_WIDTH,
      height: LOGICAL_HEIGHT,
      backgroundColor: "#171b24",
      banner: false,
      audio: { noAudio: true },
      scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
      scene: [scene],
    });
    return () => instance.destroy(true);
  }, [game]);

  return (
    <div
      ref={hostRef}
      className="game-canvas"
      role="img"
      aria-label="Игровое поле: двор, дорожки врагов и площадки для защитников"
    />
  );
}
