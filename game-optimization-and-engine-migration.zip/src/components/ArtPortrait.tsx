import { ART_NAMES, unitArtUrl, type ArtUnit } from "../game/art-types";

export function ArtPortrait({ unit, alt = "", className = "" }: { unit: ArtUnit; alt?: string; className?: string }) {
  return <img className={`art-portrait ${className}`} src={unitArtUrl(unit)} alt={alt || ART_NAMES[unit]} draggable={false} />;
}
