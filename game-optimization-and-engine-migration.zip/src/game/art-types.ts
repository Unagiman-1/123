// Главные персонажи игры. Оригинальные арты лежат в public/art/units/.
export const ART_UNITS = ["altushka", "girlfriend", "granny", "speaker", "cat", "kiosk", "patrol", "boss", "skuf"] as const;
export type ArtUnit = (typeof ART_UNITS)[number];

export const ART_NAMES: Record<ArtUnit, string> = {
  altushka: "Алтушка", girlfriend: "Подруга", granny: "Баба Валя", speaker: "Динамик",
  cat: "Кот Барсик", kiosk: "Лариса", patrol: "Дозорный", boss: "Управдом Гена", skuf: "Скуф",
};

export const unitArtUrl = (unit: ArtUnit) => `/art/units/source-${unit}.webp`;
