export interface MapRecord { stars: number; bestScore: number; bestWave: number }
export interface MetaState {
  records: Record<string, MapRecord>;
  totalStars: number;
  runs: number;
  totalKillsScore: number;
}

const KEY = "altushka-td-meta-v2";
export const emptyMeta: MetaState = { records: {}, totalStars: 0, runs: 0, totalKillsScore: 0 };

export function loadMeta(): MetaState {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return emptyMeta;
    const parsed = JSON.parse(raw) as MetaState;
    return { ...emptyMeta, ...parsed, records: parsed.records ?? {} };
  } catch { return emptyMeta; }
}

export function recordRun(meta: MetaState, mapId: string, wave: number, score: number, stars: number): MetaState {
  const previous = meta.records[mapId] ?? { stars: 0, bestScore: 0, bestWave: 0 };
  const nextRecord = { stars: Math.max(previous.stars, stars), bestScore: Math.max(previous.bestScore, score), bestWave: Math.max(previous.bestWave, wave) };
  const records = { ...meta.records, [mapId]: nextRecord };
  const next = { ...meta, records, runs: meta.runs + 1, totalKillsScore: meta.totalKillsScore + score };
  next.totalStars = Object.values(records).reduce((sum, record) => sum + record.stars, 0);
  try { localStorage.setItem(KEY, JSON.stringify(next)); } catch { /* Private browsing: keep session progress. */ }
  return next;
}

export function dailySeed() {
  const label = new Date().toISOString().slice(0, 10);
  let hash = 2166136261;
  for (let i = 0; i < label.length; i++) { hash ^= label.charCodeAt(i); hash = Math.imul(hash, 16777619); }
  return { seed: hash >>> 0, label };
}
